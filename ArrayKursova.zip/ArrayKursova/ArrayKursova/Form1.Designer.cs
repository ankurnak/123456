﻿namespace ArrayKursova
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelLogo = new System.Windows.Forms.FlowLayoutPanel();
            this.panelTitle = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panelMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.Math_operations = new System.Windows.Forms.Button();
            this.Equality = new System.Windows.Forms.Button();
            this.panelTitle.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelLogo.BackgroundImage")));
            this.panelLogo.Location = new System.Drawing.Point(-14, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(526, 372);
            this.panelLogo.TabIndex = 9;
            // 
            // panelTitle
            // 
            this.panelTitle.Controls.Add(this.textBox1);
            this.panelTitle.Location = new System.Drawing.Point(518, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(671, 372);
            this.panelTitle.TabIndex = 62;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(668, 22);
            this.textBox1.TabIndex = 60;
            // 
            // panelMenu
            // 
            this.panelMenu.Controls.Add(this.Math_operations);
            this.panelMenu.Controls.Add(this.Equality);
            this.panelMenu.Location = new System.Drawing.Point(0, 378);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1189, 327);
            this.panelMenu.TabIndex = 63;
            // 
            // Math_operations
            // 
            this.Math_operations.Location = new System.Drawing.Point(3, 3);
            this.Math_operations.Name = "Math_operations";
            this.Math_operations.Size = new System.Drawing.Size(1186, 41);
            this.Math_operations.TabIndex = 1;
            this.Math_operations.Text = "Math operations";
            this.Math_operations.UseVisualStyleBackColor = true;
            this.Math_operations.Click += new System.EventHandler(this.Math_operations_Click);
            // 
            // Equality
            // 
            this.Equality.Location = new System.Drawing.Point(3, 50);
            this.Equality.Name = "Equality";
            this.Equality.Size = new System.Drawing.Size(1186, 46);
            this.Equality.TabIndex = 2;
            this.Equality.Text = "Equality";
            this.Equality.UseVisualStyleBackColor = true;
            this.Equality.Click += new System.EventHandler(this.Equality_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 776);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelTitle);
            this.Controls.Add(this.panelLogo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel panelLogo;
        private System.Windows.Forms.FlowLayoutPanel panelTitle;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel panelMenu;
        private System.Windows.Forms.Button Math_operations;
        private System.Windows.Forms.Button Equality;
    }
}

