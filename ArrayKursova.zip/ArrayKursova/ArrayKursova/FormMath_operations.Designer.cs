﻿namespace ArrayKursova
{
    partial class FormMath_operations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.exponentiationButton = new System.Windows.Forms.Button();
            this.simplifyButton = new System.Windows.Forms.Button();
            this.divisionButton = new System.Windows.Forms.Button();
            this.multiplicationButton = new System.Windows.Forms.Button();
            this.substractionButton = new System.Windows.Forms.Button();
            this.additionButton = new System.Windows.Forms.Button();
            this.sortButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.denominatorTextBox = new System.Windows.Forms.TextBox();
            this.numeratorTextBox = new System.Windows.Forms.TextBox();
            this.exponentTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.multiplicationDenominatorTextBox = new System.Windows.Forms.TextBox();
            this.multiplicationNumeratorTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.subtractionDenominatorTextBox = new System.Windows.Forms.TextBox();
            this.subtractionNumeratorTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.divisionNumeratorTextBox = new System.Windows.Forms.TextBox();
            this.divisionDenominatorTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.additionDenominatorTextBox = new System.Windows.Forms.TextBox();
            this.additionNumeratorTextBox = new System.Windows.Forms.TextBox();
            this.fractionListBox = new System.Windows.Forms.ListBox();
            this.cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 63);
            this.panel1.TabIndex = 106;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Location = new System.Drawing.Point(1, 387);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 63);
            this.panel2.TabIndex = 107;
            // 
            // exponentiationButton
            // 
            this.exponentiationButton.Location = new System.Drawing.Point(102, 230);
            this.exponentiationButton.Name = "exponentiationButton";
            this.exponentiationButton.Size = new System.Drawing.Size(75, 23);
            this.exponentiationButton.TabIndex = 115;
            this.exponentiationButton.Text = "exponentiationButton";
            this.exponentiationButton.UseVisualStyleBackColor = true;
            this.exponentiationButton.Click += new System.EventHandler(this.exponentiationButton_Click);
            // 
            // simplifyButton
            // 
            this.simplifyButton.Location = new System.Drawing.Point(102, 178);
            this.simplifyButton.Name = "simplifyButton";
            this.simplifyButton.Size = new System.Drawing.Size(75, 23);
            this.simplifyButton.TabIndex = 114;
            this.simplifyButton.Text = "simplify";
            this.simplifyButton.UseVisualStyleBackColor = true;
            this.simplifyButton.Click += new System.EventHandler(this.simplifyButton_Click);
            // 
            // divisionButton
            // 
            this.divisionButton.Location = new System.Drawing.Point(102, 130);
            this.divisionButton.Name = "divisionButton";
            this.divisionButton.Size = new System.Drawing.Size(75, 23);
            this.divisionButton.TabIndex = 113;
            this.divisionButton.Text = "/";
            this.divisionButton.UseVisualStyleBackColor = true;
            this.divisionButton.Click += new System.EventHandler(this.divisionButton_Click);
            // 
            // multiplicationButton
            // 
            this.multiplicationButton.Location = new System.Drawing.Point(102, 83);
            this.multiplicationButton.Name = "multiplicationButton";
            this.multiplicationButton.Size = new System.Drawing.Size(75, 23);
            this.multiplicationButton.TabIndex = 112;
            this.multiplicationButton.Text = "*";
            this.multiplicationButton.UseVisualStyleBackColor = true;
            this.multiplicationButton.Click += new System.EventHandler(this.multiplicationButton_Click);
            // 
            // substractionButton
            // 
            this.substractionButton.Location = new System.Drawing.Point(1, 230);
            this.substractionButton.Name = "substractionButton";
            this.substractionButton.Size = new System.Drawing.Size(75, 23);
            this.substractionButton.TabIndex = 111;
            this.substractionButton.Text = "-";
            this.substractionButton.UseVisualStyleBackColor = true;
            this.substractionButton.Click += new System.EventHandler(this.substractionButton_Click);
            // 
            // additionButton
            // 
            this.additionButton.Location = new System.Drawing.Point(1, 178);
            this.additionButton.Name = "additionButton";
            this.additionButton.Size = new System.Drawing.Size(75, 23);
            this.additionButton.TabIndex = 110;
            this.additionButton.Text = "+";
            this.additionButton.UseVisualStyleBackColor = true;
            this.additionButton.Click += new System.EventHandler(this.additionButton_Click);
            // 
            // sortButton
            // 
            this.sortButton.Location = new System.Drawing.Point(1, 130);
            this.sortButton.Name = "sortButton";
            this.sortButton.Size = new System.Drawing.Size(75, 23);
            this.sortButton.TabIndex = 109;
            this.sortButton.Text = "sort";
            this.sortButton.UseVisualStyleBackColor = true;
            this.sortButton.Click += new System.EventHandler(this.sortButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(1, 84);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 108;
            this.addButton.Text = "add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(511, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 119;
            this.label4.Text = "Denominator";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(511, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 118;
            this.label3.Text = "Numerator";
            // 
            // denominatorTextBox
            // 
            this.denominatorTextBox.Location = new System.Drawing.Point(616, 132);
            this.denominatorTextBox.Name = "denominatorTextBox";
            this.denominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.denominatorTextBox.TabIndex = 117;
            // 
            // numeratorTextBox
            // 
            this.numeratorTextBox.Location = new System.Drawing.Point(616, 85);
            this.numeratorTextBox.Name = "numeratorTextBox";
            this.numeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.numeratorTextBox.TabIndex = 116;
            // 
            // exponentTextBox
            // 
            this.exponentTextBox.Location = new System.Drawing.Point(484, 349);
            this.exponentTextBox.Name = "exponentTextBox";
            this.exponentTextBox.Size = new System.Drawing.Size(100, 22);
            this.exponentTextBox.TabIndex = 137;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(373, 355);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 16);
            this.label14.TabIndex = 136;
            this.label14.Text = "exponent";
            // 
            // multiplicationDenominatorTextBox
            // 
            this.multiplicationDenominatorTextBox.Location = new System.Drawing.Point(652, 300);
            this.multiplicationDenominatorTextBox.Name = "multiplicationDenominatorTextBox";
            this.multiplicationDenominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.multiplicationDenominatorTextBox.TabIndex = 135;
            // 
            // multiplicationNumeratorTextBox
            // 
            this.multiplicationNumeratorTextBox.Location = new System.Drawing.Point(652, 262);
            this.multiplicationNumeratorTextBox.Name = "multiplicationNumeratorTextBox";
            this.multiplicationNumeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.multiplicationNumeratorTextBox.TabIndex = 134;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(516, 306);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 16);
            this.label13.TabIndex = 133;
            this.label13.Text = "mulDenominator";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(516, 268);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 16);
            this.label12.TabIndex = 132;
            this.label12.Text = "mulNumerator";
            // 
            // subtractionDenominatorTextBox
            // 
            this.subtractionDenominatorTextBox.Location = new System.Drawing.Point(367, 306);
            this.subtractionDenominatorTextBox.Name = "subtractionDenominatorTextBox";
            this.subtractionDenominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.subtractionDenominatorTextBox.TabIndex = 131;
            // 
            // subtractionNumeratorTextBox
            // 
            this.subtractionNumeratorTextBox.Location = new System.Drawing.Point(367, 268);
            this.subtractionNumeratorTextBox.Name = "subtractionNumeratorTextBox";
            this.subtractionNumeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.subtractionNumeratorTextBox.TabIndex = 130;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(243, 312);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 16);
            this.label11.TabIndex = 129;
            this.label11.Text = "subDenominator";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(257, 268);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 16);
            this.label10.TabIndex = 128;
            this.label10.Text = "subNumerator";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(243, 229);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 16);
            this.label9.TabIndex = 127;
            this.label9.Text = "divDenominator";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(257, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 16);
            this.label8.TabIndex = 126;
            this.label8.Text = "divNumerator";
            // 
            // divisionNumeratorTextBox
            // 
            this.divisionNumeratorTextBox.Location = new System.Drawing.Point(367, 175);
            this.divisionNumeratorTextBox.Name = "divisionNumeratorTextBox";
            this.divisionNumeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.divisionNumeratorTextBox.TabIndex = 125;
            // 
            // divisionDenominatorTextBox
            // 
            this.divisionDenominatorTextBox.Location = new System.Drawing.Point(367, 223);
            this.divisionDenominatorTextBox.Name = "divisionDenominatorTextBox";
            this.divisionDenominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.divisionDenominatorTextBox.TabIndex = 124;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(516, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 16);
            this.label7.TabIndex = 123;
            this.label7.Text = "addNumerator";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(512, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 16);
            this.label6.TabIndex = 122;
            this.label6.Text = "addDenominator";
            // 
            // additionDenominatorTextBox
            // 
            this.additionDenominatorTextBox.Location = new System.Drawing.Point(652, 223);
            this.additionDenominatorTextBox.Name = "additionDenominatorTextBox";
            this.additionDenominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.additionDenominatorTextBox.TabIndex = 121;
            // 
            // additionNumeratorTextBox
            // 
            this.additionNumeratorTextBox.Location = new System.Drawing.Point(652, 181);
            this.additionNumeratorTextBox.Name = "additionNumeratorTextBox";
            this.additionNumeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.additionNumeratorTextBox.TabIndex = 120;
            // 
            // fractionListBox
            // 
            this.fractionListBox.FormattingEnabled = true;
            this.fractionListBox.ItemHeight = 16;
            this.fractionListBox.Location = new System.Drawing.Point(291, 83);
            this.fractionListBox.Name = "fractionListBox";
            this.fractionListBox.Size = new System.Drawing.Size(120, 84);
            this.fractionListBox.TabIndex = 138;
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(24, 299);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(94, 29);
            this.cancel.TabIndex = 139;
            this.cancel.Text = "cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // FormMath_operations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.fractionListBox);
            this.Controls.Add(this.exponentTextBox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.multiplicationDenominatorTextBox);
            this.Controls.Add(this.multiplicationNumeratorTextBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.subtractionDenominatorTextBox);
            this.Controls.Add(this.subtractionNumeratorTextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.divisionNumeratorTextBox);
            this.Controls.Add(this.divisionDenominatorTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.additionDenominatorTextBox);
            this.Controls.Add(this.additionNumeratorTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.denominatorTextBox);
            this.Controls.Add(this.numeratorTextBox);
            this.Controls.Add(this.exponentiationButton);
            this.Controls.Add(this.simplifyButton);
            this.Controls.Add(this.divisionButton);
            this.Controls.Add(this.multiplicationButton);
            this.Controls.Add(this.substractionButton);
            this.Controls.Add(this.additionButton);
            this.Controls.Add(this.sortButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FormMath_operations";
            this.Text = "FormMath_operations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button exponentiationButton;
        private System.Windows.Forms.Button simplifyButton;
        private System.Windows.Forms.Button divisionButton;
        private System.Windows.Forms.Button multiplicationButton;
        private System.Windows.Forms.Button substractionButton;
        private System.Windows.Forms.Button additionButton;
        private System.Windows.Forms.Button sortButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox denominatorTextBox;
        private System.Windows.Forms.TextBox numeratorTextBox;
        private System.Windows.Forms.TextBox exponentTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox multiplicationDenominatorTextBox;
        private System.Windows.Forms.TextBox multiplicationNumeratorTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox subtractionDenominatorTextBox;
        private System.Windows.Forms.TextBox subtractionNumeratorTextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox divisionNumeratorTextBox;
        private System.Windows.Forms.TextBox divisionDenominatorTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox additionDenominatorTextBox;
        private System.Windows.Forms.TextBox additionNumeratorTextBox;
        private System.Windows.Forms.ListBox fractionListBox;
        private System.Windows.Forms.Button cancel;
    }
}