﻿namespace ArrayKursova
{
    partial class FormEquality
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lesserButton = new System.Windows.Forms.Button();
            this.greaterButton = new System.Windows.Forms.Button();
            this.lesserOrEqualButton = new System.Windows.Forms.Button();
            this.greaterOrEqualButton = new System.Windows.Forms.Button();
            this.botEqualButton = new System.Windows.Forms.Button();
            this.equalButton = new System.Windows.Forms.Button();
            this.sortButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.denominatorTextBox = new System.Windows.Forms.TextBox();
            this.numeratorTextBox = new System.Windows.Forms.TextBox();
            this.relationDenominatorTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.relationNumeratorTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.relationResultLabel = new System.Windows.Forms.TextBox();
            this.fractionListBox = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lesserButton
            // 
            this.lesserButton.Location = new System.Drawing.Point(116, 158);
            this.lesserButton.Name = "lesserButton";
            this.lesserButton.Size = new System.Drawing.Size(75, 23);
            this.lesserButton.TabIndex = 19;
            this.lesserButton.Text = "lesserButton";
            this.lesserButton.UseVisualStyleBackColor = true;
            this.lesserButton.Click += new System.EventHandler(this.lesserButton_Click);
            // 
            // greaterButton
            // 
            this.greaterButton.Location = new System.Drawing.Point(116, 108);
            this.greaterButton.Name = "greaterButton";
            this.greaterButton.Size = new System.Drawing.Size(75, 23);
            this.greaterButton.TabIndex = 18;
            this.greaterButton.Text = "greaterButton";
            this.greaterButton.UseVisualStyleBackColor = true;
            this.greaterButton.Click += new System.EventHandler(this.greaterButton_Click);
            // 
            // lesserOrEqualButton
            // 
            this.lesserOrEqualButton.Location = new System.Drawing.Point(12, 255);
            this.lesserOrEqualButton.Name = "lesserOrEqualButton";
            this.lesserOrEqualButton.Size = new System.Drawing.Size(75, 23);
            this.lesserOrEqualButton.TabIndex = 17;
            this.lesserOrEqualButton.Text = "lesserOrEqualButton";
            this.lesserOrEqualButton.UseVisualStyleBackColor = true;
            this.lesserOrEqualButton.Click += new System.EventHandler(this.lesserOrEqualButton_Click);
            // 
            // greaterOrEqualButton
            // 
            this.greaterOrEqualButton.Location = new System.Drawing.Point(12, 204);
            this.greaterOrEqualButton.Name = "greaterOrEqualButton";
            this.greaterOrEqualButton.Size = new System.Drawing.Size(75, 23);
            this.greaterOrEqualButton.TabIndex = 16;
            this.greaterOrEqualButton.Text = "greaterOrEqualButton";
            this.greaterOrEqualButton.UseVisualStyleBackColor = true;
            this.greaterOrEqualButton.Click += new System.EventHandler(this.greaterOrEqualButton_Click);
            // 
            // botEqualButton
            // 
            this.botEqualButton.Location = new System.Drawing.Point(12, 158);
            this.botEqualButton.Name = "botEqualButton";
            this.botEqualButton.Size = new System.Drawing.Size(75, 23);
            this.botEqualButton.TabIndex = 15;
            this.botEqualButton.Text = "notEqualButton";
            this.botEqualButton.UseVisualStyleBackColor = true;
            this.botEqualButton.Click += new System.EventHandler(this.botEqualButton_Click);
            // 
            // equalButton
            // 
            this.equalButton.Location = new System.Drawing.Point(12, 108);
            this.equalButton.Name = "equalButton";
            this.equalButton.Size = new System.Drawing.Size(75, 23);
            this.equalButton.TabIndex = 14;
            this.equalButton.Text = "equal";
            this.equalButton.UseVisualStyleBackColor = true;
            this.equalButton.Click += new System.EventHandler(this.equalButton_Click);
            // 
            // sortButton
            // 
            this.sortButton.Location = new System.Drawing.Point(116, 255);
            this.sortButton.Name = "sortButton";
            this.sortButton.Size = new System.Drawing.Size(75, 23);
            this.sortButton.TabIndex = 21;
            this.sortButton.Text = "sort";
            this.sortButton.UseVisualStyleBackColor = true;
            this.sortButton.Click += new System.EventHandler(this.sortButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(116, 204);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 20;
            this.addButton.Text = "add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(569, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Denominator";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(569, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Numerator";
            // 
            // denominatorTextBox
            // 
            this.denominatorTextBox.Location = new System.Drawing.Point(674, 141);
            this.denominatorTextBox.Name = "denominatorTextBox";
            this.denominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.denominatorTextBox.TabIndex = 28;
            // 
            // numeratorTextBox
            // 
            this.numeratorTextBox.Location = new System.Drawing.Point(674, 102);
            this.numeratorTextBox.Name = "numeratorTextBox";
            this.numeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.numeratorTextBox.TabIndex = 27;
            // 
            // relationDenominatorTextBox
            // 
            this.relationDenominatorTextBox.Location = new System.Drawing.Point(674, 222);
            this.relationDenominatorTextBox.Name = "relationDenominatorTextBox";
            this.relationDenominatorTextBox.Size = new System.Drawing.Size(100, 22);
            this.relationDenominatorTextBox.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(525, 228);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "relationDenominator";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(539, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "relationNumerator";
            // 
            // relationNumeratorTextBox
            // 
            this.relationNumeratorTextBox.Location = new System.Drawing.Point(674, 183);
            this.relationNumeratorTextBox.Name = "relationNumeratorTextBox";
            this.relationNumeratorTextBox.Size = new System.Drawing.Size(100, 22);
            this.relationNumeratorTextBox.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(247, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 16);
            this.label5.TabIndex = 33;
            this.label5.Text = "result";
            // 
            // relationResultLabel
            // 
            this.relationResultLabel.Location = new System.Drawing.Point(320, 228);
            this.relationResultLabel.Name = "relationResultLabel";
            this.relationResultLabel.Size = new System.Drawing.Size(100, 22);
            this.relationResultLabel.TabIndex = 32;
            // 
            // fractionListBox
            // 
            this.fractionListBox.FormattingEnabled = true;
            this.fractionListBox.ItemHeight = 16;
            this.fractionListBox.Location = new System.Drawing.Point(289, 108);
            this.fractionListBox.Name = "fractionListBox";
            this.fractionListBox.Size = new System.Drawing.Size(120, 84);
            this.fractionListBox.TabIndex = 31;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 63);
            this.panel1.TabIndex = 107;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Location = new System.Drawing.Point(3, 390);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 63);
            this.panel2.TabIndex = 108;
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(315, 294);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(94, 29);
            this.cancel.TabIndex = 140;
            this.cancel.Text = "cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // FormEquality
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.relationResultLabel);
            this.Controls.Add(this.fractionListBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.denominatorTextBox);
            this.Controls.Add(this.numeratorTextBox);
            this.Controls.Add(this.relationDenominatorTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.relationNumeratorTextBox);
            this.Controls.Add(this.sortButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.lesserButton);
            this.Controls.Add(this.greaterButton);
            this.Controls.Add(this.lesserOrEqualButton);
            this.Controls.Add(this.greaterOrEqualButton);
            this.Controls.Add(this.botEqualButton);
            this.Controls.Add(this.equalButton);
            this.Name = "FormEquality";
            this.Text = "FormEquality";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button lesserButton;
        private System.Windows.Forms.Button greaterButton;
        private System.Windows.Forms.Button lesserOrEqualButton;
        private System.Windows.Forms.Button greaterOrEqualButton;
        private System.Windows.Forms.Button botEqualButton;
        private System.Windows.Forms.Button equalButton;
        private System.Windows.Forms.Button sortButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox denominatorTextBox;
        private System.Windows.Forms.TextBox numeratorTextBox;
        private System.Windows.Forms.TextBox relationDenominatorTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox relationNumeratorTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox relationResultLabel;
        private System.Windows.Forms.ListBox fractionListBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button cancel;
    }
}